Document Embedding

Created by: Usha N
USN: 4BB23AI044

This module is part of the RAG system. It handles storing document embeddings along with the related document chunks and metadata so that the required information can be retrieved later.

Technologies proposed:
- Python
- Sentence Transformers for generating embeddings
- FAISS for storing and searching vectors

Basic flow:

Document chunks
→ Embedding generation
→ Document Embedding
→ FAISS vector index
→ Retrieval
